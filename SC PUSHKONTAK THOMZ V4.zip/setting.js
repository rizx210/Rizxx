module.exports = {
  name: "Thomz",
  version: "4.1.0",
  number: "",
  owner: {
    name: "Thomvelz",
    number: "6289603693479",
    whatsapp: "6289603693479@s.whatsapp.net",
    instagram: "https://instagram.com/thomvelz_real",
  },
  author: {
    name: "Thomvelz",
    number: "6289603693479",
    whatsapp: "6289603693479@s.whatsapp.net",
    instagram: "https://instagram.com/thomvelz_real",
  },
  features: {
    antiCall: {
      status: true,
      block: false,
    },
    selfMode: true,
    broadcast: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContact: false,
    },
    pushContacts: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContacts: false,
    },
  },
};
